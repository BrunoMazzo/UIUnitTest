import SwiftUI

@main
struct ServerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
