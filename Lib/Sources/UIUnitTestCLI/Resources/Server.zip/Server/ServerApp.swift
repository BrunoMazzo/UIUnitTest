//
//  ServerApp.swift
//  Server
//
//  Created by Bruno Mazzo on 5/3/2023.
//

import SwiftUI

@main
struct ServerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
